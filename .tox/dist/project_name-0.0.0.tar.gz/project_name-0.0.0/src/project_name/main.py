
def f():
  return 1